-- Tài liệu SQL tham khảo nhanh. CSDL chính được tạo bằng EF Core Migration.
CREATE DATABASE AssetQrManagerDb;
GO
-- Sau khi cấu hình connection string, chạy:
-- dotnet ef migrations add InitialCreate
-- dotnet ef database update
