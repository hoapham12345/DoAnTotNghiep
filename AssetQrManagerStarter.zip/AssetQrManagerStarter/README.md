# Asset QR Manager - Starter

Đồ án: Xây dựng hệ thống quản lý, kiểm kê và bảo trì thiết bị máy tính bằng mã QR.

## Có sẵn trong starter
- ASP.NET Core MVC + EF Core + SQL Server
- ASP.NET Core Identity
- 4 role: Admin, Technician, Manager, Viewer
- Entity cho phòng ban, vị trí, nhân viên, thiết bị, cấu hình máy tính/màn hình/máy in
- Entity cấp phát, sửa chữa, bảo trì, kiểm kê
- Dashboard cơ bản
- CRUD bước đầu: danh sách + thêm + xem chi tiết thiết bị
- URL công khai theo QR token: `/device/qr/{token}`
- Sinh mã tài sản dạng `PC-2026-0001`, `MON-2026-0001`, `PRN-2026-0001`

## 1. Yêu cầu
- Visual Studio hỗ trợ .NET 10 hoặc .NET SDK 10
- SQL Server / SQL Server Express

Nếu máy chỉ có .NET 8, có thể đổi `net10.0` thành `net8.0` và dùng package EF/Identity 8.x tương ứng.

## 2. Sửa connection string
File `appsettings.json`:

```json
"DefaultConnection": "Server=YOUR_SERVER;Database=AssetQrManagerDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true"
```

Ví dụ SQL Express:
`Server=.\\SQLEXPRESS;Database=AssetQrManagerDb;Trusted_Connection=True;TrustServerCertificate=True;`

## 3. Tạo database
Mở Terminal tại project:

```bash
dotnet tool install --global dotnet-ef
dotnet restore
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```

## 4. Tài khoản demo
- Email: `admin@local.test`
- Password: `Admin@123`

Hãy đổi mật khẩu seed trước khi dùng thật.

## 5. Bước tiếp theo nên làm
1. Edit/Delete mềm thiết bị
2. Form cấu hình riêng theo loại thiết bị
3. Sinh ảnh QR bằng QRCoder + trang in tem
4. Cấp phát/thu hồi/điều chuyển
5. Báo hỏng & phiếu sửa chữa
6. Lập lịch + lịch sử bảo trì
7. Tạo đợt kiểm kê + quét QR xác nhận
8. Dashboard Chart.js
9. Xuất Excel/PDF
10. Audit log
