using AssetQrManager.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AssetQrManager.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Location> Locations => Set<Location>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<DeviceType> DeviceTypes => Set<DeviceType>();
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<ComputerSpec> ComputerSpecs => Set<ComputerSpec>();
    public DbSet<MonitorSpec> MonitorSpecs => Set<MonitorSpec>();
    public DbSet<PrinterSpec> PrinterSpecs => Set<PrinterSpec>();
    public DbSet<DeviceAssignment> DeviceAssignments => Set<DeviceAssignment>();
    public DbSet<RepairTicket> RepairTickets => Set<RepairTicket>();
    public DbSet<MaintenancePlan> MaintenancePlans => Set<MaintenancePlan>();
    public DbSet<MaintenanceHistory> MaintenanceHistories => Set<MaintenanceHistory>();
    public DbSet<InventorySession> InventorySessions => Set<InventorySession>();
    public DbSet<InventoryDetail> InventoryDetails => Set<InventoryDetail>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Device>().HasIndex(x => x.AssetCode).IsUnique();
        builder.Entity<Device>().HasIndex(x => x.QrToken).IsUnique();
        builder.Entity<Device>().HasIndex(x => x.SerialNumber).IsUnique().HasFilter("[SerialNumber] IS NOT NULL");
        builder.Entity<Employee>().HasIndex(x => x.EmployeeCode).IsUnique();

        builder.Entity<ComputerSpec>().HasIndex(x => x.DeviceId).IsUnique();
        builder.Entity<MonitorSpec>().HasIndex(x => x.DeviceId).IsUnique();
        builder.Entity<PrinterSpec>().HasIndex(x => x.DeviceId).IsUnique();

        builder.Entity<Device>().HasQueryFilter(x => !x.IsDeleted);

        builder.Entity<Department>()
            .HasOne(x => x.Parent)
            .WithMany()
            .HasForeignKey(x => x.ParentId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Entity<Location>()
            .HasOne(x => x.Parent)
            .WithMany()
            .HasForeignKey(x => x.ParentId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
