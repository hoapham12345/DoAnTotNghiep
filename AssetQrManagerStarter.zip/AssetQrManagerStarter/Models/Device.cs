using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AssetQrManager.Models;

public class DeviceType
{
    public int Id { get; set; }
    [Required, MaxLength(100)] public string Name { get; set; } = string.Empty;
    [Required, MaxLength(20)] public string CodePrefix { get; set; } = string.Empty;
}

public class Device
{
    public int Id { get; set; }
    [Required, MaxLength(30)] public string AssetCode { get; set; } = string.Empty;
    [Required, MaxLength(200)] public string DeviceName { get; set; } = string.Empty;
    public int DeviceTypeId { get; set; }
    public DeviceType? DeviceType { get; set; }

    [MaxLength(100)] public string? SerialNumber { get; set; }
    [MaxLength(100)] public string? Manufacturer { get; set; }
    [MaxLength(100)] public string? Model { get; set; }

    public DateTime? PurchaseDate { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal? PurchasePrice { get; set; }
    public DateTime? WarrantyExpirationDate { get; set; }

    public int? LocationId { get; set; }
    public Location? Location { get; set; }
    public int? AssignedEmployeeId { get; set; }
    public Employee? AssignedEmployee { get; set; }

    public DeviceStatus Status { get; set; } = DeviceStatus.InStock;
    [Required, MaxLength(64)] public string QrToken { get; set; } = Guid.NewGuid().ToString("N");
    [MaxLength(300)] public string? ImagePath { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }

    public ComputerSpec? ComputerSpec { get; set; }
    public MonitorSpec? MonitorSpec { get; set; }
    public PrinterSpec? PrinterSpec { get; set; }
}

public class ComputerSpec
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    [MaxLength(150)] public string? CPU { get; set; }
    [MaxLength(100)] public string? RAM { get; set; }
    [MaxLength(150)] public string? Storage { get; set; }
    [MaxLength(150)] public string? GPU { get; set; }
    [MaxLength(120)] public string? OperatingSystem { get; set; }
    [MaxLength(50)] public string? OsVersion { get; set; }
    [MaxLength(50)] public string? IpAddress { get; set; }
    [MaxLength(50)] public string? MacAddress { get; set; }
}

public class MonitorSpec
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    [MaxLength(50)] public string? ScreenSize { get; set; }
    [MaxLength(50)] public string? Resolution { get; set; }
    [MaxLength(50)] public string? PanelType { get; set; }
    [MaxLength(30)] public string? RefreshRate { get; set; }
}

public class PrinterSpec
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    [MaxLength(80)] public string? PrinterType { get; set; }
    public bool ColorSupport { get; set; }
    [MaxLength(50)] public string? PaperSize { get; set; }
    public bool NetworkSupport { get; set; }
    [MaxLength(50)] public string? IpAddress { get; set; }
}
