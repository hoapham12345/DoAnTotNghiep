using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AssetQrManager.Models;

public class DeviceAssignment
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    public int? EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public int? LocationId { get; set; }
    public Location? Location { get; set; }
    public DateTime AssignedDate { get; set; }
    public DateTime? ReturnedDate { get; set; }
    [MaxLength(500)] public string? ConditionAtAssignment { get; set; }
    [MaxLength(500)] public string? ConditionAtReturn { get; set; }
    [MaxLength(1000)] public string? Note { get; set; }
}

public class RepairTicket
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    [Required, MaxLength(2000)] public string ProblemDescription { get; set; } = string.Empty;
    [MaxLength(20)] public string Priority { get; set; } = "Normal";
    public RepairStatus Status { get; set; } = RepairStatus.New;
    public DateTime ReportedDate { get; set; } = DateTime.UtcNow;
    public DateTime? StartDate { get; set; }
    public DateTime? CompletedDate { get; set; }
    [MaxLength(450)] public string? AssignedTechnicianId { get; set; }
    [MaxLength(2000)] public string? Cause { get; set; }
    [MaxLength(2000)] public string? Solution { get; set; }
    [Column(TypeName = "decimal(18,2)")] public decimal RepairCost { get; set; }
}

public class MaintenancePlan
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    public int IntervalMonths { get; set; } = 6;
    public DateTime? LastMaintenanceDate { get; set; }
    public DateTime NextMaintenanceDate { get; set; }
    public bool IsActive { get; set; } = true;
}

public class MaintenanceHistory
{
    public int Id { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    public DateTime MaintenanceDate { get; set; }
    [Required, MaxLength(2000)] public string Content { get; set; } = string.Empty;
    [MaxLength(1000)] public string? Result { get; set; }
    [MaxLength(1000)] public string? Note { get; set; }
    [MaxLength(450)] public string? TechnicianId { get; set; }
}

public class InventorySession
{
    public int Id { get; set; }
    [Required, MaxLength(200)] public string Name { get; set; } = string.Empty;
    public int? LocationId { get; set; }
    public Location? Location { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public bool IsClosed { get; set; }
    public ICollection<InventoryDetail> Details { get; set; } = new List<InventoryDetail>();
}

public class InventoryDetail
{
    public int Id { get; set; }
    public int InventorySessionId { get; set; }
    public InventorySession? InventorySession { get; set; }
    public int DeviceId { get; set; }
    public Device? Device { get; set; }
    public InventoryResult Result { get; set; } = InventoryResult.Pending;
    public DateTime? CheckedAt { get; set; }
    public int? ActualLocationId { get; set; }
    public int? ActualEmployeeId { get; set; }
    [MaxLength(1000)] public string? Note { get; set; }
}
