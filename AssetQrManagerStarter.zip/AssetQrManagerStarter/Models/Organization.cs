using System.ComponentModel.DataAnnotations;

namespace AssetQrManager.Models;

public class Department
{
    public int Id { get; set; }
    [Required, MaxLength(150)] public string Name { get; set; } = string.Empty;
    public int? ParentId { get; set; }
    public Department? Parent { get; set; }
}

public class Location
{
    public int Id { get; set; }
    [Required, MaxLength(150)] public string Name { get; set; } = string.Empty;
    [MaxLength(100)] public string? Building { get; set; }
    [MaxLength(50)] public string? Floor { get; set; }
    public int? ParentId { get; set; }
    public Location? Parent { get; set; }
}

public class Employee
{
    public int Id { get; set; }
    [Required, MaxLength(30)] public string EmployeeCode { get; set; } = string.Empty;
    [Required, MaxLength(150)] public string FullName { get; set; } = string.Empty;
    [MaxLength(150)] public string? Email { get; set; }
    [MaxLength(20)] public string? Phone { get; set; }
    public int? DepartmentId { get; set; }
    public Department? Department { get; set; }
    public bool IsActive { get; set; } = true;
}
