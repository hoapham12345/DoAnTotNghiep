namespace AssetQrManager.Models;

public enum DeviceStatus
{
    InStock = 1,
    InUse = 2,
    UnderRepair = 3,
    Broken = 4,
    PendingDisposal = 5,
    Disposed = 6,
    Lost = 7
}

public enum RepairStatus
{
    New = 1,
    Accepted = 2,
    Repairing = 3,
    WaitingForParts = 4,
    Completed = 5,
    CannotRepair = 6
}

public enum InventoryResult
{
    Pending = 0,
    Present = 1,
    NotFound = 2,
    WrongLocation = 3,
    WrongUser = 4,
    StatusMismatch = 5
}
