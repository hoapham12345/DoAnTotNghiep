using AssetQrManager.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AssetQrManager.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly ApplicationDbContext _db;
    public HomeController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        ViewBag.TotalDevices = await _db.Devices.CountAsync();
        ViewBag.InUse = await _db.Devices.CountAsync(x => x.Status == Models.DeviceStatus.InUse);
        ViewBag.UnderRepair = await _db.Devices.CountAsync(x => x.Status == Models.DeviceStatus.UnderRepair);
        ViewBag.OverdueMaintenance = await _db.MaintenancePlans.CountAsync(x => x.IsActive && x.NextMaintenanceDate < DateTime.Today);
        return View();
    }
}
