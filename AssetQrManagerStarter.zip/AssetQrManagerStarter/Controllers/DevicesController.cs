using AssetQrManager.Data;
using AssetQrManager.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace AssetQrManager.Controllers;

[Authorize]
public class DevicesController : Controller
{
    private readonly ApplicationDbContext _db;
    public DevicesController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? q, int? typeId, DeviceStatus? status)
    {
        var query = _db.Devices
            .Include(x => x.DeviceType)
            .Include(x => x.Location)
            .Include(x => x.AssignedEmployee)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(x => x.AssetCode.Contains(q) || x.DeviceName.Contains(q) || (x.SerialNumber != null && x.SerialNumber.Contains(q)));
        if (typeId.HasValue) query = query.Where(x => x.DeviceTypeId == typeId.Value);
        if (status.HasValue) query = query.Where(x => x.Status == status.Value);

        ViewBag.DeviceTypes = new SelectList(await _db.DeviceTypes.OrderBy(x => x.Name).ToListAsync(), "Id", "Name", typeId);
        return View(await query.OrderByDescending(x => x.Id).ToListAsync());
    }

    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> Create()
    {
        await LoadLookups();
        return View(new Device());
    }

    [HttpPost, ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> Create(Device model)
    {
        if (!ModelState.IsValid)
        {
            await LoadLookups();
            return View(model);
        }

        var type = await _db.DeviceTypes.FindAsync(model.DeviceTypeId);
        if (type is null) return BadRequest("Loại thiết bị không hợp lệ.");

        model.AssetCode = await GenerateAssetCodeAsync(type.CodePrefix);
        model.QrToken = Guid.NewGuid().ToString("N");
        model.CreatedAt = DateTime.UtcNow;

        _db.Devices.Add(model);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [AllowAnonymous]
    [Route("device/qr/{token}")]
    public async Task<IActionResult> Qr(string token)
    {
        var device = await _db.Devices
            .Include(x => x.DeviceType)
            .Include(x => x.Location)
            .Include(x => x.AssignedEmployee)
            .FirstOrDefaultAsync(x => x.QrToken == token);
        return device is null ? NotFound() : View("Details", device);
    }

    public async Task<IActionResult> Details(int id)
    {
        var device = await _db.Devices
            .Include(x => x.DeviceType)
            .Include(x => x.Location)
            .Include(x => x.AssignedEmployee)
            .FirstOrDefaultAsync(x => x.Id == id);
        return device is null ? NotFound() : View(device);
    }

    private async Task LoadLookups()
    {
        ViewBag.DeviceTypes = new SelectList(await _db.DeviceTypes.OrderBy(x => x.Name).ToListAsync(), "Id", "Name");
        ViewBag.Locations = new SelectList(await _db.Locations.OrderBy(x => x.Name).ToListAsync(), "Id", "Name");
        ViewBag.Employees = new SelectList(await _db.Employees.Where(x => x.IsActive).OrderBy(x => x.FullName).ToListAsync(), "Id", "FullName");
    }

    private async Task<string> GenerateAssetCodeAsync(string prefix)
    {
        var year = DateTime.Today.Year;
        var basePrefix = $"{prefix}-{year}-";
        var lastCode = await _db.Devices.IgnoreQueryFilters()
            .Where(x => x.AssetCode.StartsWith(basePrefix))
            .OrderByDescending(x => x.AssetCode)
            .Select(x => x.AssetCode)
            .FirstOrDefaultAsync();

        var next = 1;
        if (lastCode is not null && int.TryParse(lastCode.Split('-').Last(), out var n)) next = n + 1;
        return $"{basePrefix}{next:0000}";
    }
}
